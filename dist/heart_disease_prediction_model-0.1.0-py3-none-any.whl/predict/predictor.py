import pandas as pd

def predict(model, new_data):
    return model.predict(new_data)
